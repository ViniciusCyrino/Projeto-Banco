public class Main{
	
	
	public static void main (String[] args) {
		
		Interface grafico = new Interface();
		grafico.criaBanco();
	    grafico.tela_de_entrada();
		
	}}
