
public class extrato {
	
	double info;
	
	
	extrato (double info){
		
		this.info = info;
	}

}
